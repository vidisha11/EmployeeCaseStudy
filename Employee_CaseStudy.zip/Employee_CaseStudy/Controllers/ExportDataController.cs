﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using Employee_CaseStudy.Models;
using ClosedXML.Excel;
using System.IO;


namespace Employee_CaseStudy.Controllers
{
    public class ExportDataController : Controller
    {
        // GET: ExportData
        [Authorize]
        public ActionResult Index()
        {
            String constring = ConfigurationManager.ConnectionStrings["ExportConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            string query = "select * From Analytics_Table";
            DataTable dt = new DataTable();
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            con.Close();
            IList<ExportDataToExcel> model = new List<ExportDataToExcel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                model.Add(new ExportDataToExcel()
                {
                    ID = Convert.ToInt32(dt.Rows[i]["Id"]),
                    Name = dt.Rows[i]["Name"].ToString(),
                    Email = dt.Rows[i]["Email"].ToString(),
                    Country = dt.Rows[i]["Country"].ToString(),
                });
            }
            return View(model);
        }

        [Authorize]
        public ActionResult ExportData()
        {
            String constring = ConfigurationManager.ConnectionStrings["ExportConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(constring);
            string query = "select * From Analytics_Table";
            DataTable dt = new DataTable();
            dt.TableName = "Analytics_Table";
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            da.Fill(dt);
            con.Close();

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                wb.Style.Font.Bold = true;

                Response.Clear();
                Response.Buffer = true;
                Response.Charset = "";
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.AddHeader("content-disposition", "attachment;filename= EmployeeReport.xlsx");

                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    wb.SaveAs(MyMemoryStream);
                    MyMemoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }
            }
            return RedirectToAction("Index", "ExportData");
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }
    }

}




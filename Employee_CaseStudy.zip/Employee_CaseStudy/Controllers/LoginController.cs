﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Employee_CaseStudy;
using Employee_CaseStudy.Models;

namespace Employee_CaseStudy.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login_Action()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Login_Action(Login user)
        {
            if (ModelState.IsValid)
            {
                using (LoginEntities db = new LoginEntities())
                {
                    var obj = db.Logins.Where(a => a.Username.Equals(user.Username) && a.Pswd.Equals(user.Pswd)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["UserID"] = obj.UserId.ToString();
                        Session["UserName"] = obj.Username.ToString();
                        return RedirectToAction("UserDashboard");
                    }
                }
            }
            return View(user);
        }

        [Authorize]
        public ActionResult UserDashboard()
        {
            if (Session["UserID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login_Action");
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Employee_CaseStudy.Models;

namespace Employee_CaseStudy.Controllers
{
    [HandleError]
    [Authorize]
    public class DetailsController : Controller
    {
        private DetailsEntities db = new DetailsEntities();

        // GET: Details
        public ActionResult Index(string SearchBy, string Search)
        {
            if (SearchBy == "Age")
            {
                int SearchAge = Convert.ToInt16(Search);
                return View(db.Employee_Details.Where(x => x.Age == SearchAge).ToList());
            }

            else if (SearchBy == "Marital_Status")
            {
                return View(db.Employee_Details.Where(x => x.Marital_Status == Search || Search == null).ToList());
            }

            else
            {
                return View(db.Employee_Details.Where(x => x.Name.StartsWith(Search) || Search == null).ToList());
            }
        }

        // GET: Details/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Details employee_Details = db.Employee_Details.Find(id);
            if (employee_Details == null)
            {
                return HttpNotFound();
            }
            return View(employee_Details);
        }

        // GET: Details/Create
        [Authorize]
        public ActionResult Create()
        {
            return View();
        }

        // POST: Details/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Create([Bind(Include = "Id,Name,Age,Marital_Status,Primary_skills,secondary_skills")] Employee_Details employee_Details)
        {
            if (ModelState.IsValid)
            {
                db.Employee_Details.Add(employee_Details);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee_Details);
        }

        // GET: Details/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Details employee_Details = db.Employee_Details.Find(id);
            if (employee_Details == null)
            {
                return HttpNotFound();
            }
            return View(employee_Details);
        }

        // POST: Details/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult Edit([Bind(Include = "Id,Name,Age,Marital_Status,Primary_skills,secondary_skills")] Employee_Details employee_Details)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_Details).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee_Details);
        }

        // GET: Details/Delete/5
        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Details employee_Details = db.Employee_Details.Find(id);
            if (employee_Details == null)
            {
                return HttpNotFound();
            }
            return View(employee_Details);
        }

        // POST: Details/Delete/5
        [HttpPost, ActionName("Delete")]
        [Authorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_Details employee_Details = db.Employee_Details.Find(id);
            db.Employee_Details.Remove(employee_Details);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
